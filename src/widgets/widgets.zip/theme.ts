export const Theme = {
    cornerRadius: 4,
    strokeColor: "#444",
    fillColor: "#eee",
    hoverFill: "#ddd",
    activeFill: "#ccc",
    fontSize: 16,
    fontFamily: "system-ui",
    accentColor: "#49a6e9",
  };